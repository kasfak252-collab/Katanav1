package com.katanasmp;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;

/**
 * Shadow Realm mechanic: hide inside the shadow of any entity for up to an hour.
 * You are ejected if the host drops to 5 hearts or less, and the katana refuses
 * to let you hide in dangerous auras (bosses, max-level katana holders...).
 */
public class ShadowHideManager {
    private static class State {
        BukkitRunnable task;
        long since;
    }

    private final KatanaPlugin plugin;
    private final Map<UUID, State> hiding = new HashMap<UUID, State>();
    private final Map<UUID, Long> cooldown = new HashMap<UUID, Long>();

    public ShadowHideManager(KatanaPlugin plugin) { this.plugin = plugin; }

    public boolean isHiding(Player p) { return hiding.containsKey(p.getUniqueId()); }

    public long hidingSince(Player p) { State s = hiding.get(p.getUniqueId()); return s == null ? 0 : s.since; }

    private boolean dangerous(LivingEntity h) {
        if (Util.isBoss(h)) return true;
        if (h.getMaxHealth() > plugin.getConfig().getDouble("shadow-hide.danger-max-health", 100.0)) return true;
        CustomMobRegistry.Entry cm = plugin.mobs().match(h);
        if (cm != null && cm.boss) return true;
        if (h instanceof Player) {
            Player pl = (Player) h;
            Katana k = plugin.katanas().identify(pl.getInventory().getItemInMainHand());
            if (k != null && plugin.data().level(pl.getUniqueId(), k.id) >= plugin.getConfig().getInt("shadow-hide.danger-level", 12)) return true;
        }
        return false;
    }

    public void hide(final Player p, org.bukkit.entity.Entity host) {
        if (isHiding(p)) { exit(p, plugin.msg("shadow-exit")); return; }
        if (!(host instanceof LivingEntity) || host == p) return;
        final LivingEntity h = (LivingEntity) host;
        long now = System.currentTimeMillis();
        Long cd = cooldown.get(p.getUniqueId());
        if (cd != null && cd > now) return;
        cooldown.put(p.getUniqueId(), now + plugin.getConfig().getLong("shadow-hide.cooldown-seconds", 5) * 1000L);

        if (dangerous(h)) { p.sendMessage(plugin.msg("shadow-danger")); return; }
        final double minHp = plugin.getConfig().getDouble("shadow-hide.min-host-health", 10.0);
        if (h.getHealth() <= minHp) { p.sendMessage(plugin.msg("shadow-weak")); return; }

        final long until = now + plugin.getConfig().getLong("shadow-hide.minutes", 60) * 60000L;
        State s = new State();
        s.since = now;
        p.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, 20 * 60 * 61, 0, false, false), true);
        p.setInvulnerable(true);
        p.setCollidable(false);
        p.sendMessage(plugin.msg("shadow-enter"));

        s.task = new BukkitRunnable() {
            public void run() {
                if (!p.isOnline() || p.isDead()) { cleanup(p); return; }
                if (h.isDead() || !h.isValid()) { exit(p, plugin.msg("shadow-ejected")); return; }
                if (h.getHealth() <= minHp) { exit(p, plugin.msg("shadow-ejected")); return; }
                if (System.currentTimeMillis() > until) { exit(p, plugin.msg("shadow-exit")); return; }
                Location t = h.getLocation().clone();
                Location pl = p.getLocation();
                t.setYaw(pl.getYaw());
                t.setPitch(pl.getPitch());
                if (pl.getWorld() != t.getWorld() || pl.distanceSquared(t) > 0.5) p.teleport(t);
                Util.particle(t.clone().add(0, 0.1, 0), "SQUID_INK", 2, 0.3, 0.05, 0.3, 0.01, "#4B0082");
            }
        };
        s.task.runTaskTimer(plugin, 2L, 2L);
        hiding.put(p.getUniqueId(), s);
    }

    public void exit(Player p, String message) {
        if (!cleanup(p)) return;
        if (p.isOnline()) {
            if (message != null && !message.isEmpty()) p.sendMessage(message);
            Util.particle(p.getLocation().add(0, 1, 0), "SQUID_INK", 25, 0.4, 0.7, 0.4, 0.05, "#4B0082");
        }
    }

    private boolean cleanup(Player p) {
        State s = hiding.remove(p.getUniqueId());
        if (s == null) return false;
        try { s.task.cancel(); } catch (IllegalStateException ignored) { }
        p.removePotionEffect(PotionEffectType.INVISIBILITY);
        p.setInvulnerable(false);
        p.setCollidable(true);
        return true;
    }

    public void shutdown() {
        for (UUID u : new ArrayList<UUID>(hiding.keySet())) {
            Player p = Bukkit.getPlayer(u);
            if (p != null) cleanup(p);
        }
        hiding.clear();
    }
}
