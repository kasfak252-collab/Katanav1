package com.katanasmp;

import org.bukkit.configuration.ConfigurationSection;

import java.util.*;

/** A katana definition (loaded from katanas.yml or registered through the API). */
public class Katana {
    public final String id;
    public String name;
    public String element = "NONE";
    public String baseMaterial = "NETHERITE_SWORD";
    public String color = "#FFFFFF";
    public String auraParticle = "FLAME";
    public String hitParticle = "FLAME";
    public String source = "Katanas";
    public int cmd;
    public double auraRadius = 0.9;
    public List<String> themeMobs = new ArrayList<String>();
    public List<String> finalBoss = new ArrayList<String>();
    public TreeMap<Integer, List<String>> passives = new TreeMap<Integer, List<String>>();
    public TreeMap<Integer, List<String>> onHit = new TreeMap<Integer, List<String>>();
    public Map<String, Integer> flags = new HashMap<String, Integer>();
    public Map<String, TreeMap<Integer, Double>> stats = new HashMap<String, TreeMap<Integer, Double>>();
    public Map<Slot, List<AbilityDef>> abilities = new EnumMap<Slot, List<AbilityDef>>(Slot.class);

    public Katana(String id) {
        this.id = id;
        this.name = id;
        for (Slot s : Slot.values()) abilities.put(s, new ArrayList<AbilityDef>());
    }

    public static Katana load(String id, ConfigurationSection c) {
        Katana k = new Katana(id);
        k.name = c.getString("name", id);
        k.element = c.getString("element", "NONE");
        k.cmd = c.getInt("cmd", 0);
        k.color = c.getString("color", "#FFFFFF");
        k.baseMaterial = c.getString("material", "NETHERITE_SWORD");
        ConfigurationSection aura = c.getConfigurationSection("aura");
        if (aura != null) {
            k.auraParticle = aura.getString("particle", "FLAME");
            k.auraRadius = aura.getDouble("radius", 0.9);
        }
        k.hitParticle = c.getString("hit-particle", k.auraParticle);
        k.themeMobs = upper(c.getStringList("theme-mobs"));
        k.finalBoss = upper(c.getStringList("final-boss"));
        tiers(c.getConfigurationSection("passives"), k.passives);
        tiers(c.getConfigurationSection("on-hit"), k.onHit);

        ConfigurationSection fl = c.getConfigurationSection("flags");
        if (fl != null) for (String f : fl.getKeys(false)) k.flags.put(f.toUpperCase(Locale.ROOT), fl.getInt(f, 1));

        ConfigurationSection st = c.getConfigurationSection("stats");
        if (st != null) {
            for (String key : st.getKeys(false)) {
                ConfigurationSection s2 = st.getConfigurationSection(key);
                if (s2 == null) continue;
                TreeMap<Integer, Double> tm = new TreeMap<Integer, Double>();
                for (String lv : s2.getKeys(false)) {
                    try { tm.put(Integer.parseInt(lv), s2.getDouble(lv)); } catch (NumberFormatException ignored) { }
                }
                k.stats.put(key.toLowerCase(Locale.ROOT), tm);
            }
        }

        for (Slot s : Slot.values()) {
            List<AbilityDef> list = k.abilities.get(s);
            for (ConfigurationSection sec : Util.sections(c, s.name().toLowerCase(Locale.ROOT))) {
                list.add(new AbilityDef(s, sec));
            }
            Collections.sort(list, new Comparator<AbilityDef>() {
                public int compare(AbilityDef a, AbilityDef b) { return Integer.compare(a.unlock, b.unlock); }
            });
        }
        return k;
    }

    private static List<String> upper(List<String> in) {
        List<String> out = new ArrayList<String>();
        for (String s : in) out.add(s.toUpperCase(Locale.ROOT));
        return out;
    }

    private static void tiers(ConfigurationSection sec, TreeMap<Integer, List<String>> into) {
        if (sec == null) return;
        for (String key : sec.getKeys(false)) {
            try { into.put(Integer.parseInt(key), sec.getStringList(key)); } catch (NumberFormatException ignored) { }
        }
    }

    /** Highest stage whose unlock level is reached, or null if still locked. */
    public AbilityDef ability(Slot s, int level) {
        AbilityDef best = null;
        for (AbilityDef a : abilities.get(s)) if (a.unlock <= level) best = a;
        return best;
    }

    /** Lowest unlock level of a slot, 0 if the katana has no such ability. */
    public int firstUnlock(Slot s) {
        List<AbilityDef> l = abilities.get(s);
        return l.isEmpty() ? 0 : l.get(0).unlock;
    }

    public boolean has(String flag, int level) {
        Integer u = flags.get(flag);
        return u != null && level >= u;
    }

    public double stat(String key, int level, double def) {
        TreeMap<Integer, Double> tm = stats.get(key);
        if (tm == null) return def;
        Map.Entry<Integer, Double> e = tm.floorEntry(level);
        return e == null ? def : e.getValue();
    }
}
