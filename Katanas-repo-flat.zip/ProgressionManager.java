package com.katanasmp;

import com.katanasmp.api.KatanaKillCreditEvent;
import com.katanasmp.api.KatanaLevelUpEvent;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.util.*;

/** Hard-task level progression (progression.yml). Custom mobs from other plugins count too. */
public class ProgressionManager {

    public static class Task {
        public String type = "KILL";
        public int amount = 10;
        public List<String> mobs = new ArrayList<String>();
        public List<String> env = new ArrayList<String>();
        public String slot = "ANY";
        public String desc = "";
        public boolean theme;

        static Task of(ConfigurationSection c) {
            Task t = new Task();
            t.type = c.getString("type", "KILL").toUpperCase(Locale.ROOT);
            t.amount = Math.max(1, c.getInt("amount", 10));
            for (String s : c.getStringList("mobs")) t.mobs.add(s.toUpperCase(Locale.ROOT));
            for (String s : c.getStringList("environment")) t.env.add(s.toUpperCase(Locale.ROOT));
            t.slot = c.getString("slot", "ANY").toUpperCase(Locale.ROOT);
            t.desc = c.getString("desc", t.type + " " + t.amount);
            t.theme = c.getBoolean("theme", false);
            return t;
        }
    }

    public static class KillInfo {
        public String type = "UNKNOWN";
        public String customId;
        public int credit = 1;
        public boolean boss;
        public boolean hostile;
        public String env = "NORMAL";
    }

    private final KatanaPlugin plugin;
    private final Map<Integer, Task> defaults = new HashMap<Integer, Task>();
    private final Map<String, Map<Integer, Task>> overrides = new HashMap<String, Map<Integer, Task>>();

    public ProgressionManager(KatanaPlugin plugin) { this.plugin = plugin; }

    public void load() {
        defaults.clear();
        overrides.clear();
        YamlConfiguration y = YamlConfiguration.loadConfiguration(new File(plugin.getDataFolder(), "progression.yml"));
        readTasks(y.getConfigurationSection("default"), defaults);
        ConfigurationSection ov = y.getConfigurationSection("overrides");
        if (ov != null) {
            for (String id : ov.getKeys(false)) {
                Map<Integer, Task> m = new HashMap<Integer, Task>();
                readTasks(ov.getConfigurationSection(id), m);
                overrides.put(id.toLowerCase(), m);
            }
        }
    }

    private void readTasks(ConfigurationSection sec, Map<Integer, Task> into) {
        if (sec == null) return;
        for (String key : sec.getKeys(false)) {
            ConfigurationSection c = sec.getConfigurationSection(key);
            if (c == null) continue;
            try { into.put(Integer.parseInt(key), Task.of(c)); } catch (NumberFormatException ignored) { }
        }
    }

    public Task taskFor(Katana k, int level) {
        Map<Integer, Task> o = overrides.get(k.id);
        if (o != null && o.containsKey(level)) return o.get(level);
        return defaults.get(level);
    }

    public String describe(Katana k, int level) {
        Task t = taskFor(k, level);
        if (t == null) return "-";
        return t.desc.replace("{amount}", String.valueOf(t.amount)).replace("{element}", k.element);
    }

    // ------------------------------------------------------------------ events

    public void creditKill(Player p, Katana k, KillInfo info) {
        KatanaKillCreditEvent ev = new KatanaKillCreditEvent(p, k.id, info.type, info.customId, info.credit, info.boss);
        Bukkit.getPluginManager().callEvent(ev);
        if (ev.isCancelled() || ev.getCredit() <= 0) return;
        info.credit = ev.getCredit();
        info.boss = ev.isBoss();
        onKill(p, k, info);
    }

    public void onKill(Player p, Katana k, KillInfo i) {
        UUID u = p.getUniqueId();
        int streak = plugin.data().streak(u) + 1;
        plugin.data().setStreak(u, streak);
        int level = plugin.data().level(u, k.id);
        if (level >= plugin.maxLevel()) return;
        Task t = taskFor(k, level);
        if (t == null) return;
        if (t.type.equals("KILL")) {
            if (matchesKill(t, k, i)) add(p, k, t, i.credit, false);
        } else if (t.type.equals("BOSS")) {
            boolean ok = !k.finalBoss.isEmpty()
                    ? (k.finalBoss.contains(i.type) || (i.customId != null && i.boss))
                    : i.boss;
            if (ok) add(p, k, t, 1, false);
        } else if (t.type.equals("STREAK")) {
            setTo(p, k, t, streak, false);
        }
    }

    private boolean matchesKill(Task t, Katana k, KillInfo i) {
        if (!t.env.isEmpty() && !t.env.contains(i.env)) return false;
        List<String> list = t.theme ? Collections.singletonList("THEME") : t.mobs;
        if (list.isEmpty()) return true;
        for (String m : list) {
            if (m.equals("ANY")) return true;
            if (m.equals("ANY_HOSTILE")) { if (i.hostile || i.customId != null) return true; continue; }
            if (m.equals("THEME")) {
                if (k.themeMobs.contains(i.type) || i.customId != null) return true;
                continue;
            }
            if (m.startsWith("CUSTOM:")) {
                if (i.customId != null && i.customId.equalsIgnoreCase(m.substring(7))) return true;
                continue;
            }
            if (m.equals(i.type)) return true;
        }
        return false;
    }

    public void onAbility(Player p, Katana k, Slot s) {
        int level = plugin.data().level(p.getUniqueId(), k.id);
        if (level >= plugin.maxLevel()) return;
        Task t = taskFor(k, level);
        if (t != null && t.type.equals("ABILITY") && (t.slot.equals("ANY") || t.slot.equals(s.name()))) add(p, k, t, 1, false);
    }

    public void onBlocked(Player p, Katana k, int n) {
        int level = plugin.data().level(p.getUniqueId(), k.id);
        if (level >= plugin.maxLevel()) return;
        Task t = taskFor(k, level);
        if (t != null && t.type.equals("BLOCK")) add(p, k, t, n, false);
    }

    public void onTravel(Player p, Katana k, int blocks) {
        int level = plugin.data().level(p.getUniqueId(), k.id);
        if (level >= plugin.maxLevel()) return;
        Task t = taskFor(k, level);
        if (t != null && t.type.equals("TRAVEL")) add(p, k, t, blocks, true);
    }

    /** Dying resets the kill streak and any STREAK task progress. */
    public void onDeath(Player p) {
        UUID u = p.getUniqueId();
        plugin.data().setStreak(u, 0);
        for (Katana k : plugin.katanas().all()) {
            int level = plugin.data().level(u, k.id);
            Task t = taskFor(k, level);
            if (t != null && t.type.equals("STREAK")) plugin.data().setProgress(u, k.id, 0);
        }
    }

    private void add(Player p, Katana k, Task t, int amt, boolean quiet) {
        setTo(p, k, t, plugin.data().progress(p.getUniqueId(), k.id) + amt, quiet);
    }

    private void setTo(Player p, Katana k, Task t, int value, boolean quiet) {
        UUID u = p.getUniqueId();
        plugin.data().setProgress(u, k.id, value);
        if (value >= t.amount) { levelUp(p, k); return; }
        if (!quiet || value % 25 == 0) plugin.bar(p, "&7[" + k.name + "&7] &f" + value + "&7/&f" + t.amount);
    }

    public void levelUp(Player p, Katana k) {
        UUID u = p.getUniqueId();
        int cur = plugin.data().level(u, k.id);
        int max = plugin.maxLevel();
        if (cur >= max) return;
        int nl = cur + 1;
        KatanaLevelUpEvent ev = new KatanaLevelUpEvent(p, k.id, cur, nl);
        Bukkit.getPluginManager().callEvent(ev);
        if (ev.isCancelled()) return;
        plugin.data().setLevel(u, k.id, nl);
        plugin.data().setProgress(u, k.id, 0);
        plugin.katanas().refresh(p, k, nl);
        p.sendMessage(plugin.msg("level-up").replace("{katana}", Util.color(k.name)).replace("{level}", String.valueOf(nl)));
        try { p.sendTitle(Util.color(k.name), Util.color("&eLevel " + nl), 10, 50, 10); } catch (Throwable ignored) { }
        Util.sound(p.getLocation(), "ENTITY_PLAYER_LEVELUP", 1f, 1f);
        Util.particle(p.getLocation().add(0, 1, 0), "END_ROD", 40, 0.5, 1, 0.5, 0.1, k.color);
        if (nl >= max) {
            if (plugin.getConfig().getBoolean("progression.announce-max-level", true)) {
                Bukkit.broadcastMessage(plugin.msg("max-level").replace("{player}", p.getName()).replace("{katana}", Util.color(k.name)));
            }
        } else {
            p.sendMessage(plugin.msg("next-task").replace("{task}", describe(k, nl)));
        }
    }
}
