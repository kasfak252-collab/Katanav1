package com.katanasmp;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.*;

/**
 * One repeating task (every 2 ticks) that drives everything passive:
 * aura particles, potion passives, flags (silent steps, night flight, fear/wipe/pressure auras),
 * the vibration radar, the infinity projectile barrier and travel tracking.
 */
public class TickTask extends BukkitRunnable {
    private final KatanaPlugin plugin;
    private int tick = 0;
    private final Set<UUID> silenced = new HashSet<UUID>();
    private final Set<UUID> flight = new HashSet<UUID>();
    private final Map<UUID, Set<PotionEffectType>> applied = new HashMap<UUID, Set<PotionEffectType>>();
    private final Map<UUID, Location> lastLoc = new HashMap<UUID, Location>();
    private final Map<UUID, Double> travelAcc = new HashMap<UUID, Double>();
    private final Map<UUID, Long> pressureMsg = new HashMap<UUID, Long>();
    private final Map<UUID, Location> radarSeen = new HashMap<UUID, Location>();

    public TickTask(KatanaPlugin plugin) { this.plugin = plugin; }

    @Override
    public void run() {
        tick += 2;
        for (Player p : Bukkit.getOnlinePlayers()) {
            Katana k = plugin.katanas().identify(p.getInventory().getItemInMainHand());
            if (k == null) { release(p); continue; }
            if (p.isDead()) continue;
            int level = plugin.data().level(p.getUniqueId(), k.id);
            aura(p, k, level);
            if (tick % 4 == 0) infinity(p, k, level);
            if (tick % 10 == 0) {
                passives(p, k, level);
                flags(p, k, level);
                travel(p, k);
            }
            if (tick % 20 == 0) plugin.katanas().refresh(p, k, level);
        }
        if (radarSeen.size() > 800) radarSeen.clear();
    }

    /** Called when a player stops holding a katana (or quits): undo everything we applied. */
    public void release(Player p) {
        UUID u = p.getUniqueId();
        if (silenced.remove(u)) p.setSilent(false);
        if (flight.remove(u)) stopFlight(p);
        Set<PotionEffectType> a = applied.remove(u);
        if (a != null) for (PotionEffectType t : a) p.removePotionEffect(t);
        lastLoc.remove(u);
    }

    public void releaseAll() {
        for (Player p : Bukkit.getOnlinePlayers()) release(p);
    }

    // ------------------------------------------------------------------- aura

    private void aura(Player p, Katana k, int level) {
        if (!plugin.getConfig().getBoolean("aura.enabled", true)) return;
        if (p.getGameMode() == GameMode.SPECTATOR || plugin.shadow().isHiding(p)) return;
        double r = k.auraRadius * (0.8 + 0.2 * level / 12.0);
        int points = level >= 8 ? 3 : (level >= 4 ? 2 : 1);
        double base = tick * 0.09;
        Location loc = p.getLocation();
        for (int i = 0; i < points; i++) {
            double ang = base + i * 2 * Math.PI / points;
            double y = 1.0 + 0.5 * Math.sin(tick * 0.05 + i * 2);
            Util.particle(loc.clone().add(Math.cos(ang) * r, y, Math.sin(ang) * r), k.auraParticle, 1, 0, 0, 0, 0, k.color);
        }
        if (level >= 12) {
            double ang = -base * 1.5;
            Util.particle(loc.clone().add(Math.cos(ang) * r * 0.6, 2.1, Math.sin(ang) * r * 0.6), k.auraParticle, 1, 0, 0, 0, 0, k.color);
        }
    }

    // ---------------------------------------------------------------- passives

    private void passives(Player p, Katana k, int level) {
        UUID u = p.getUniqueId();
        Map<String, String> eff = new LinkedHashMap<String, String>();
        for (Map.Entry<Integer, List<String>> en : k.passives.entrySet()) {
            if (en.getKey() > level) break;
            for (String s : en.getValue()) {
                String base = s.split("@")[0];
                eff.put(base.split(":")[0].trim().toUpperCase(Locale.ROOT), s);
            }
        }
        Set<PotionEffectType> now = new HashSet<PotionEffectType>();
        for (String s : eff.values()) {
            String[] pc = s.split("@", 2);
            if (pc.length > 1 && !Util.cond(p, pc[1])) continue;
            PotionEffectType type = Util.potionType(pc[0].split(":")[0]);
            if (type == null) continue;
            int dur = type.equals(PotionEffectType.NIGHT_VISION) ? 260 : 40;
            PotionEffect pe = Util.effect(pc[0], dur, true, false);
            if (pe == null) continue;
            p.addPotionEffect(pe, true);
            now.add(type);
        }
        Set<PotionEffectType> prev = applied.put(u, now);
        if (prev != null) for (PotionEffectType t : prev) if (!now.contains(t)) p.removePotionEffect(t);
    }

    // ------------------------------------------------------------------- flags

    private boolean survivalLike(Player p) {
        return p.getGameMode() == GameMode.SURVIVAL || p.getGameMode() == GameMode.ADVENTURE;
    }

    private void stopFlight(Player p) {
        if (survivalLike(p)) { p.setFlying(false); p.setAllowFlight(false); }
    }

    private void flags(Player p, Katana k, int level) {
        UUID u = p.getUniqueId();
        if (k.has("SILENT", level) && silenced.add(u)) p.setSilent(true);

        if (k.has("NIGHT_FLIGHT", level) && plugin.getConfig().getBoolean("night-flight.enabled", true)
                && Util.isNight(p.getWorld()) && survivalLike(p)) {
            if (!p.getAllowFlight()) { p.setAllowFlight(true); flight.add(u); }
            if (p.isFlying()) Util.particle(p.getLocation().add(0, 1.2, 0), "REDSTONE", 6, 0.5, 0.4, 0.5, 0, k.color);
        } else if (flight.remove(u)) {
            stopFlight(p);
        }

        if (plugin.data().aura(u, k.id)) {
            if (k.has("MOB_FEAR", level)) fear(p, k, level);
            if (k.has("MOB_WIPE", level)) wipe(p, k, level);
            if (k.has("PRESSURE", level)) pressure(p, k);
            if (k.has("AURA_BURN", level)) burn(p, k, level);
        }
        if (k.has("VIBRATION_RADAR", level)) radar(p, k, level);
    }

    private boolean skip(Entity e) {
        if (Util.isBoss(e) || plugin.mobs().isCustom(e)) return true;
        return plugin.getConfig().getBoolean("mob-aura.skip-named", true) && e.getCustomName() != null;
    }

    private void fear(Player p, Katana k, int level) {
        double r = k.stat("fear-radius", level, 10);
        double killR = k.stat("fear-kill-radius", level, 3);
        double killHp = k.stat("fear-kill-health", level, 30);
        Location c = p.getLocation();
        for (Entity e : p.getNearbyEntities(r, r, r)) {
            if (!(e instanceof LivingEntity) || e instanceof Player || !Util.hostile(e) || skip(e)) continue;
            LivingEntity le = (LivingEntity) e;
            if (le instanceof Mob) ((Mob) le).setTarget(null);
            Vector away = le.getLocation().toVector().subtract(c.toVector());
            double d = away.length();
            if (d < 0.1) continue;
            if (d <= killR && le.getMaxHealth() <= killHp) { plugin.abilities().killQuiet(p, le); continue; }
            Vector v = away.normalize().multiply(0.45);
            v.setY(0.12);
            le.setVelocity(v);
        }
    }

    private void wipe(Player p, Katana k, int level) {
        double r = k.stat("wipe-radius", level, 8);
        for (Entity e : p.getNearbyEntities(r, r, r)) {
            if (!(e instanceof LivingEntity) || e instanceof Player || !Util.hostile(e) || skip(e)) continue;
            LivingEntity le = (LivingEntity) e;
            if (le.getMaxHealth() > 120) continue;
            Util.particle(le.getLocation().add(0, 1, 0), "END_ROD", 10, 0.3, 0.5, 0.3, 0.05, k.color);
            plugin.abilities().killQuiet(p, le);
        }
    }

    private void burn(Player p, Katana k, int level) {
        double r = k.stat("burn-radius", level, 3);
        for (Entity e : p.getNearbyEntities(r, r, r)) {
            if (!(e instanceof LivingEntity) || e instanceof Player || !Util.hostile(e) || skip(e)) continue;
            e.setFireTicks(Math.max(e.getFireTicks(), 60));
        }
    }

    /** "Lobby pressure": pulsing rings around the holder and a heavy-aura message for nearby players. */
    private void pressure(Player p, Katana k) {
        if (tick % 40 != 0) return;
        Location c = p.getLocation().add(0, 0.2, 0);
        for (int i = 1; i <= 3; i++) Util.ring(c, 3.0 * i, 20, k.auraParticle, k.color, i);
        double pr = plugin.getConfig().getDouble("pressure.radius", 20);
        long cdMs = plugin.getConfig().getLong("pressure.message-cooldown-seconds", 12) * 1000L;
        long now = System.currentTimeMillis();
        List<String> fx = plugin.getConfig().getStringList("pressure.effects");
        for (Player o : p.getWorld().getPlayers()) {
            if (o == p || o.getLocation().distanceSquared(p.getLocation()) > pr * pr) continue;
            Long last = pressureMsg.get(o.getUniqueId());
            if (last == null || now - last > cdMs) {
                plugin.bar(o, plugin.msg("pressure"));
                pressureMsg.put(o.getUniqueId(), now);
            }
            for (String s : fx) {
                PotionEffect pe = Util.effect(s, 60, false, true);
                if (pe != null) o.addPotionEffect(pe, true);
            }
        }
    }

    /** Echo Pulse: shows ripples (only to the holder) where living things are moving nearby. */
    private void radar(Player p, Katana k, int level) {
        double r = k.stat("radar-radius", level, 8);
        for (Entity e : p.getNearbyEntities(r, r, r)) {
            if (!(e instanceof LivingEntity) || e instanceof ArmorStand) continue;
            if (!(e instanceof Player) && !Util.hostile(e)) continue;
            Location prev = radarSeen.put(e.getUniqueId(), e.getLocation());
            if (prev != null && prev.getWorld() == e.getWorld() && prev.distanceSquared(e.getLocation()) > 0.04) {
                Util.playerParticle(p, e.getLocation().add(0, 0.1, 0), "NOTE", 2, 0.2, 0.05, 0.2, 1, k.color);
            }
        }
    }

    // ------------------------------------------------------- projectile barrier

    /** Gravity Edge / Celestial Blade "infinity": incoming projectiles slow down and get stopped or reflected. */
    private void infinity(Player p, Katana k, int level) {
        if (!k.has("PROJECTILE_BARRIER", level) || !plugin.data().aura(p.getUniqueId(), k.id)) return;
        double r = k.stat("infinity-radius", level, 8);
        boolean reflect = k.stat("infinity-reflect", level, 0) > 0;
        Location eye = p.getEyeLocation();
        for (Entity e : p.getNearbyEntities(r, r, r)) {
            if (!(e instanceof Projectile) || e.isOnGround() || plugin.abilities().isOwn(e, p)) continue;
            Projectile pr = (Projectile) e;
            Vector v = pr.getVelocity();
            Vector to = eye.toVector().subtract(pr.getLocation().toVector());
            double dist = to.length();
            boolean still = v.lengthSquared() < 0.01;
            if (!still && v.dot(to) <= 0) continue;
            if (dist <= 2.5 || still) {
                if (reflect) {
                    pr.setVelocity(v.multiply(-1));
                    try { pr.setShooter(p); } catch (Throwable ignored) { }
                } else {
                    Util.particle(pr.getLocation(), k.auraParticle, 6, 0.1, 0.1, 0.1, 0.02, k.color);
                    pr.remove();
                }
                plugin.progression().onBlocked(p, k, 1);
            } else {
                pr.setVelocity(v.multiply(0.55));
            }
        }
    }

    // ------------------------------------------------------------------ travel

    private void travel(Player p, Katana k) {
        UUID u = p.getUniqueId();
        Location now = p.getLocation();
        Location last = lastLoc.put(u, now);
        if (p.isInsideVehicle() || last == null || last.getWorld() != now.getWorld()) return;
        double d = last.distance(now);
        if (d < 0.2 || d > 30) return;
        Double acc = travelAcc.get(u);
        double total = (acc == null ? 0 : acc) + d;
        int whole = (int) total;
        travelAcc.put(u, total - whole);
        if (whole > 0) plugin.progression().onTravel(p, k, whole);
    }
}
