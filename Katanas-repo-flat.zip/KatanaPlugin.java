package com.katanasmp;

import com.katanasmp.api.KatanaAPI;
import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;
import org.bukkit.plugin.ServicePriority;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

public class KatanaPlugin extends JavaPlugin {
    private static KatanaPlugin instance;
    private KatanaManager katanas;
    private PlayerDataManager data;
    private ProgressionManager progression;
    private AbilityManager abilities;
    private CustomMobRegistry mobs;
    private ShadowHideManager shadow;
    private ResourcePackManager pack;
    private TickTask tick;
    private KatanaAPI api;
    private final Map<String, Slot> triggers = new HashMap<String, Slot>();
    private final Map<Slot, String> labels = new HashMap<Slot, String>();

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();
        saveIfMissing("katanas.yml");
        saveIfMissing("progression.yml");

        katanas = new KatanaManager(this);
        data = new PlayerDataManager(this);
        mobs = new CustomMobRegistry(this);
        progression = new ProgressionManager(this);
        abilities = new AbilityManager(this);
        shadow = new ShadowHideManager(this);
        pack = new ResourcePackManager(this);
        loadAll();

        api = new KatanaAPI(this);
        getServer().getServicesManager().register(KatanaAPI.class, api, this, ServicePriority.Normal);
        getServer().getPluginManager().registerEvents(new KatanaListener(this), this);

        KatanaCommand cmd = new KatanaCommand(this);
        for (String c : new String[]{"katana", "crimson", "celestial", "shadow", "gravity"}) {
            PluginCommand pc = getCommand(c);
            if (pc != null) { pc.setExecutor(cmd); pc.setTabCompleter(cmd); }
        }

        tick = new TickTask(this);
        tick.runTaskTimer(this, 20L, 2L);

        long save = Math.max(1L, getConfig().getLong("data.autosave-minutes", 5)) * 60L * 20L;
        Bukkit.getScheduler().runTaskTimer(this, new Runnable() {
            public void run() { data.save(); }
        }, save, save);

        getLogger().info("Loaded " + katanas.all().size() + " katanas.");
    }

    @Override
    public void onDisable() {
        if (tick != null) { tick.releaseAll(); tick.cancel(); }
        if (shadow != null) shadow.shutdown();
        if (abilities != null) abilities.shutdown();
        if (data != null) data.save();
    }

    /** (Re)loads every config file. */
    public void loadAll() {
        reloadConfig();
        katanas.load();
        progression.load();
        mobs.loadConfig();
        buildTriggers();
    }

    private void saveIfMissing(String name) {
        if (!new File(getDataFolder(), name).exists()) saveResource(name, false);
    }

    private void buildTriggers() {
        triggers.clear();
        labels.clear();
        put(Slot.ACTIVE, getConfig().getString("keybinds.active", "SWAP_HANDS"));
        put(Slot.DEFENSE, getConfig().getString("keybinds.defense", "SNEAK_RIGHT_CLICK"));
        put(Slot.ULTIMATE, getConfig().getString("keybinds.ultimate", "DROP_ITEM"));
    }

    private void put(Slot s, String trigger) {
        String t = trigger.toUpperCase();
        triggers.put(t, s);
        String label;
        switch (t) {
            case "SWAP_HANDS": label = "F"; break;
            case "SNEAK_SWAP_HANDS": label = "Shift+F"; break;
            case "DROP_ITEM": label = "Q"; break;
            case "SNEAK_RIGHT_CLICK": label = "Shift+Right-Click"; break;
            case "RIGHT_CLICK": label = "Right-Click"; break;
            default: label = t;
        }
        labels.put(s, label);
    }

    public Slot slotFor(String trigger) { return triggers.get(trigger); }
    public String keyLabel(Slot s) { String l = labels.get(s); return l == null ? s.name() : l; }
    public int maxLevel() { return Math.max(1, getConfig().getInt("max-level", 12)); }

    public String msg(String key) { return Util.color(getConfig().getString("messages." + key, key)); }

    public void bar(Player p, String msg) {
        try {
            p.spigot().sendMessage(ChatMessageType.ACTION_BAR, new TextComponent(Util.color(msg)));
        } catch (Throwable t) {
            p.sendMessage(Util.color(msg));
        }
    }

    public static KatanaPlugin get() { return instance; }
    public KatanaManager katanas() { return katanas; }
    public PlayerDataManager data() { return data; }
    public ProgressionManager progression() { return progression; }
    public AbilityManager abilities() { return abilities; }
    public CustomMobRegistry mobs() { return mobs; }
    public ShadowHideManager shadow() { return shadow; }
    public ResourcePackManager pack() { return pack; }
    public TickTask tick() { return tick; }
}
