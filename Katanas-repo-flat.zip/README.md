# Katanas (Minecraft plugin)

15 levelling katanas with auras, skills, domains, custom-mob API. Works on Spigot / Paper 1.13 -> latest.

All files are in the repo root on purpose (easy to upload from a phone).
Build: GitHub -> **Actions** -> **Build Katanas jar** -> **Run workflow** -> download **Katanas-jar** from Artifacts.
Put `Katanas.jar` into your server's `plugins/` folder.

Keys: F = active skill, Shift+Right-Click = barrier, Q = ultimate (Shift+Q drops the sword).
Admin: `/katana give <player> <id> [level]`, `/katana list`, `/katana reload`.
Resource pack: build with `python3 make_pack.py` or use the zip provided separately.
