package com.katanasmp.api;

import com.katanasmp.Slot;
import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

/** Fired before a katana skill runs. Cancel it to stop the cast (e.g. inside protected regions). */
public class KatanaAbilityCastEvent extends Event implements Cancellable {
    private static final HandlerList HANDLERS = new HandlerList();
    private final Player player;
    private final String katanaId;
    private final String abilityName;
    private final Slot slot;
    private final int level;
    private boolean cancelled;

    public KatanaAbilityCastEvent(Player player, String katanaId, String abilityName, Slot slot, int level) {
        this.player = player; this.katanaId = katanaId; this.abilityName = abilityName; this.slot = slot; this.level = level;
    }

    public Player getPlayer() { return player; }
    public String getKatanaId() { return katanaId; }
    public String getAbilityName() { return abilityName; }
    public Slot getSlot() { return slot; }
    public int getLevel() { return level; }
    public boolean isCancelled() { return cancelled; }
    public void setCancelled(boolean c) { cancelled = c; }
    public HandlerList getHandlers() { return HANDLERS; }
    public static HandlerList getHandlerList() { return HANDLERS; }
}
