package com.katanasmp.api;

import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

/**
 * Fired when a kill is about to count towards a katana task. Other plugins can change the
 * credit (e.g. give a custom boss x10) or cancel it.
 */
public class KatanaKillCreditEvent extends Event implements Cancellable {
    private static final HandlerList HANDLERS = new HandlerList();
    private final Player player;
    private final String katanaId;
    private final String mobType;
    private final String customMobId;
    private int credit;
    private boolean boss;
    private boolean cancelled;

    public KatanaKillCreditEvent(Player player, String katanaId, String mobType, String customMobId, int credit, boolean boss) {
        this.player = player; this.katanaId = katanaId; this.mobType = mobType;
        this.customMobId = customMobId; this.credit = credit; this.boss = boss;
    }

    public Player getPlayer() { return player; }
    public String getKatanaId() { return katanaId; }
    public String getMobType() { return mobType; }
    /** null for vanilla mobs. */
    public String getCustomMobId() { return customMobId; }
    public int getCredit() { return credit; }
    public void setCredit(int credit) { this.credit = Math.max(0, credit); }
    public boolean isBoss() { return boss; }
    public void setBoss(boolean boss) { this.boss = boss; }
    public boolean isCancelled() { return cancelled; }
    public void setCancelled(boolean c) { cancelled = c; }
    public HandlerList getHandlers() { return HANDLERS; }
    public static HandlerList getHandlerList() { return HANDLERS; }
}
