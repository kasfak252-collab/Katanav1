package com.katanasmp;

import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Per-player katana levels, task progress and aura toggles (playerdata.yml). */
public class PlayerDataManager {
    private final KatanaPlugin plugin;
    private final File file;
    private YamlConfiguration y;
    private final Map<UUID, Integer> streak = new HashMap<UUID, Integer>();

    public PlayerDataManager(KatanaPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "playerdata.yml");
        load();
    }

    public void load() { y = YamlConfiguration.loadConfiguration(file); }

    public void save() {
        try { y.save(file); } catch (IOException e) { plugin.getLogger().warning("Could not save playerdata.yml: " + e.getMessage()); }
    }

    private String path(UUID u, String id, String k) { return "players." + u + "." + id + "." + k; }

    public int level(UUID u, String id) {
        return Math.max(1, Math.min(plugin.maxLevel(), y.getInt(path(u, id, "level"), 1)));
    }

    public void setLevel(UUID u, String id, int level) { y.set(path(u, id, "level"), Math.max(1, Math.min(plugin.maxLevel(), level))); }

    public int progress(UUID u, String id) { return y.getInt(path(u, id, "progress"), 0); }

    public void setProgress(UUID u, String id, int v) { y.set(path(u, id, "progress"), v); }

    public boolean aura(UUID u, String id) {
        return y.getBoolean(path(u, id, "aura"), plugin.getConfig().getBoolean("aura-default", true));
    }

    public void setAura(UUID u, String id, boolean on) { y.set(path(u, id, "aura"), on); }

    public int streak(UUID u) { Integer s = streak.get(u); return s == null ? 0 : s; }

    public void setStreak(UUID u, int v) { streak.put(u, v); }
}
