package com.katanasmp;

import com.katanasmp.api.KatanaAbilityCastEvent;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.WeatherType;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.entity.Tameable;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.metadata.MetadataValue;
import org.bukkit.potion.PotionEffect;
import org.bukkit.projectiles.ProjectileSource;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.*;

/**
 * Cooldowns + the generic skill engine. Every skill in katanas.yml is one of:
 * DASH, WAVE, BOLT, BLINK, PULSE, BARRIER or DOMAIN, tuned by its parameters.
 * Power scales with the katana level (about 54% at level 1 up to 100% at level 12).
 */
public class AbilityManager {
    private static final int INTERVAL = 5; // domain tick interval in game ticks

    private final KatanaPlugin plugin;
    private final Map<UUID, Map<String, Long>> cooldowns = new HashMap<UUID, Map<String, Long>>();
    private final Map<UUID, BarrierState> barriers = new HashMap<UUID, BarrierState>();
    private final Set<UUID> pullMode = new HashSet<UUID>();
    private final Set<UUID> activeDomains = new HashSet<UUID>();
    private final Map<UUID, LivingEntity> bound = new HashMap<UUID, LivingEntity>();
    private final Set<UUID> skyPlayers = new HashSet<UUID>();
    private final Random rnd = new Random();
    private int rainAlive = 0;

    /** When true the damage listener ignores hits (our own skill damage must not trigger on-hit procs). */
    public boolean suppressHit = false;

    private static class BarrierState {
        long until;
        boolean anchor;
        double reduction;
        List<String> recoil = new ArrayList<String>();
    }

    public AbilityManager(KatanaPlugin plugin) { this.plugin = plugin; }

    static double scale(int level) { return 0.5 + 0.5 * Math.min(12, level) / 12.0; }

    // ===================================================================== cast

    public void cast(Player p, Katana k, Slot slot) {
        UUID u = p.getUniqueId();
        int level = plugin.data().level(u, k.id);
        AbilityDef a = k.ability(slot, level);
        if (a == null) {
            int need = k.firstUnlock(slot);
            if (need > 0) plugin.bar(p, plugin.msg("locked").replace("{level}", String.valueOf(need)));
            return;
        }
        String key = k.id + ":" + slot.name();
        long now = System.currentTimeMillis();
        Map<String, Long> m = cooldowns.get(u);
        if (m == null) { m = new HashMap<String, Long>(); cooldowns.put(u, m); }
        Long until = m.get(key);
        if (until != null && until > now) {
            long secs = (until - now + 999) / 1000;
            plugin.bar(p, plugin.msg("cooldown").replace("{seconds}", String.valueOf(secs)));
            return;
        }
        KatanaAbilityCastEvent ev = new KatanaAbilityCastEvent(p, k.id, a.name, slot, level);
        Bukkit.getPluginManager().callEvent(ev);
        if (ev.isCancelled()) return;

        boolean ok;
        try {
            ok = run(p, k, a, level);
        } catch (Throwable t) {
            plugin.getLogger().warning("Ability " + a.name + " failed: " + t);
            ok = false;
        }
        if (!ok) return;

        double cd = a.d("cooldown", 20);
        if (k.has("OPEN_SKY_CDR", level) && Util.openSky(p.getLocation())) {
            cd *= plugin.getConfig().getDouble("abilities.open-sky-cooldown-multiplier", 0.8);
        }
        m.put(key, now + (long) (cd * 1000));
        plugin.progression().onAbility(p, k, slot);
        plugin.bar(p, "&a" + a.name + "&7!");
    }

    private boolean run(Player p, Katana k, AbilityDef a, int level) {
        if (a.type.equals("DASH")) return dash(p, k, a, level);
        if (a.type.equals("WAVE")) return wave(p, k, a, level);
        if (a.type.equals("BOLT")) return bolt(p, k, a, level);
        if (a.type.equals("BLINK")) return blink(p, k, a, level);
        if (a.type.equals("PULSE")) return pulse(p, k, a, level);
        if (a.type.equals("BARRIER")) return barrier(p, k, a, level);
        if (a.type.equals("DOMAIN")) return domain(p, k, a, level);
        plugin.getLogger().warning("Unknown ability type: " + a.type);
        return false;
    }

    // ================================================================== helpers

    public boolean valid(Player p, Entity e) {
        if (e == p || !(e instanceof LivingEntity) || e.isDead() || e instanceof ArmorStand) return false;
        if (e instanceof Player) {
            Player t = (Player) e;
            if (!plugin.getConfig().getBoolean("abilities.affect-players", true)) return false;
            if (!t.getWorld().getPVP()) return false;
            if (t.getGameMode() == GameMode.SPECTATOR || t.getGameMode() == GameMode.CREATIVE) return false;
            return !plugin.shadow().isHiding(t);
        }
        if (e.hasMetadata("NPC")) return false;
        if (e instanceof Tameable && ((Tameable) e).isTamed()) return false;
        if (!plugin.getConfig().getBoolean("abilities.affect-passive", false)
                && !Util.hostile(e) && !plugin.mobs().isCustom(e)) return false;
        return true;
    }

    private List<LivingEntity> nearby(Location c, double r, Player self) {
        List<LivingEntity> out = new ArrayList<LivingEntity>();
        World w = c.getWorld();
        if (w == null) return out;
        for (Entity e : w.getNearbyEntities(c, r, r, r)) {
            if (valid(self, e) && e.getLocation().distanceSquared(c) <= (r + 1.0) * (r + 1.0)) out.add((LivingEntity) e);
        }
        return out;
    }

    private LivingEntity lookTarget(Player p, double range) {
        Location eye = p.getEyeLocation();
        Vector dir = eye.getDirection().normalize();
        LivingEntity best = null;
        double bestScore = -1;
        for (LivingEntity e : nearby(eye, range, p)) {
            Vector to = e.getEyeLocation().toVector().subtract(eye.toVector());
            double dist = to.length();
            if (dist < 0.5 || dist > range) continue;
            double dot = to.normalize().dot(dir);
            if (dot < 0.93 || !p.hasLineOfSight(e)) continue;
            double score = dot - dist * 0.004;
            if (score > bestScore) { bestScore = score; best = e; }
        }
        return best;
    }

    private Location rayEnd(Player p, double range) {
        Location cur = p.getEyeLocation();
        Vector step = cur.getDirection().normalize().multiply(0.5);
        for (double i = 0; i < range; i += 0.5) {
            cur.add(step);
            if (!cur.getBlock().isPassable()) { cur.subtract(step); break; }
        }
        return cur;
    }

    private boolean passable(Location l) {
        return l.getBlock().isPassable() && l.clone().add(0, 1, 0).getBlock().isPassable();
    }

    public void hurt(Player src, LivingEntity t, double dmg) {
        if (dmg <= 0 || t.isDead()) return;
        boolean old = suppressHit;
        suppressHit = true;
        try {
            t.setNoDamageTicks(0);
            if (src != null) t.damage(dmg, src); else t.damage(dmg);
        } finally {
            suppressHit = old;
        }
    }

    public void killQuiet(Player src, LivingEntity t) { hurt(src, t, t.getMaxHealth() * 10); }

    public void heal(Player p, double amt) {
        if (amt <= 0 || p.isDead()) return;
        p.setHealth(Math.min(p.getMaxHealth(), p.getHealth() + amt));
    }

    public boolean isOwn(Entity e, Player p) {
        if (e instanceof Projectile) {
            ProjectileSource s = ((Projectile) e).getShooter();
            if (s == p) return true;
        }
        Player o = ownerOf(e);
        return o != null && o.equals(p);
    }

    private String metaString(Entity e, String key) {
        for (MetadataValue v : e.getMetadata(key)) if (v.getOwningPlugin() == plugin) return v.asString();
        return null;
    }

    private double metaDouble(Entity e, String key, double def) {
        for (MetadataValue v : e.getMetadata(key)) if (v.getOwningPlugin() == plugin) return v.asDouble();
        return def;
    }

    public Player ownerOf(Entity e) {
        String s = metaString(e, "katana_owner");
        if (s == null) return null;
        try { return Bukkit.getPlayer(UUID.fromString(s)); } catch (IllegalArgumentException ex) { return null; }
    }

    // ----------------------------------------------------------------- effects

    public void applyEffects(LivingEntity t, Player src, List<String> specs) {
        for (String s : specs) applyEffect(t, src, s);
    }

    /** Potion specs plus FIRE / BIND / DAMAGE / SELF specials (see katanas.yml header). */
    public void applyEffect(LivingEntity t, Player src, String spec) {
        String[] parts = spec.split(":");
        String key = parts[0].trim().toUpperCase(Locale.ROOT);
        if (key.equals("SELF")) {
            if (src != null && spec.length() > 5) {
                PotionEffect pe = Util.effect(spec.substring(5), 40, false, true);
                if (pe != null) src.addPotionEffect(pe, true);
            }
            return;
        }
        if (key.equals("FIRE")) {
            if (roll(parts, 2)) t.setFireTicks(Math.max(t.getFireTicks(), (int) num(parts, 1, 60)));
            return;
        }
        if (key.equals("DAMAGE")) {
            if (roll(parts, 2)) hurt(src, t, num(parts, 1, 1));
            return;
        }
        if (key.equals("BIND")) {
            if (roll(parts, 2)) bind(t, (int) num(parts, 1, 40));
            return;
        }
        PotionEffect pe = Util.effect(spec, 40, false, true);
        if (pe != null) t.addPotionEffect(pe, true);
    }

    private double num(String[] parts, int idx, double def) {
        if (parts.length <= idx) return def;
        try { return Double.parseDouble(parts[idx].trim()); } catch (NumberFormatException e) { return def; }
    }

    private boolean roll(String[] parts, int idx) { return rnd.nextDouble() <= num(parts, idx, 1.0); }

    private void bind(final LivingEntity t, int ticks) {
        if (t instanceof Player || Util.isBoss(t) || !(t instanceof Mob)) return;
        if (bound.containsKey(t.getUniqueId())) return;
        bound.put(t.getUniqueId(), t);
        t.setAI(false);
        Util.particle(t.getLocation().add(0, 1, 0), "END_ROD", 12, 0.3, 0.6, 0.3, 0.02, "#FFFFFF");
        Bukkit.getScheduler().runTaskLater(plugin, new Runnable() {
            public void run() {
                bound.remove(t.getUniqueId());
                if (!t.isDead()) t.setAI(true);
            }
        }, ticks);
    }

    // ===================================================================== DASH

    private boolean dash(final Player p, final Katana k, final AbilityDef a, final int level) {
        final double sc = scale(level);
        final double dist = a.d("distance", 8) * (0.7 + 0.3 * level / 12.0);
        final int steps = 6;
        Vector d = p.getEyeLocation().getDirection();
        if (!a.b("vertical", false)) d.setY(0);
        if (d.lengthSquared() < 0.01) d = p.getLocation().getDirection().setY(0);
        if (d.lengthSquared() < 0.01) return false;
        final Vector dir = d.normalize();
        final double stepLen = dist / steps;
        final double dmg = a.d("damage", 5) * sc;
        final double healPct = a.d("heal-pct", 0);
        final String particle = a.s("particle", k.auraParticle);
        final List<String> fx = a.list("effects");
        final int trailLife = a.i("trail-lifetime", 0);
        final Set<UUID> hit = new HashSet<UUID>();
        final List<Location> path = new ArrayList<Location>();
        Util.particle(p.getLocation().add(0, 1, 0), particle, 20, 0.3, 0.6, 0.3, 0.05, k.color);

        new BukkitRunnable() {
            int i = 0;
            public void run() {
                if (!p.isOnline() || p.isDead()) { cancel(); return; }
                Location next = p.getLocation().clone().add(dir.clone().multiply(stepLen));
                if (!passable(next)) { finishDash(); return; }
                p.teleport(next);
                p.setFallDistance(0f);
                Util.particle(next.clone().add(0, 1, 0), particle, 12, 0.3, 0.5, 0.3, 0.02, k.color);
                path.add(next.clone().add(0, 0.3, 0));
                for (LivingEntity t : nearby(next.clone().add(0, 1, 0), 1.8, p)) {
                    if (!hit.add(t.getUniqueId())) continue;
                    hurt(p, t, dmg);
                    applyEffects(t, p, fx);
                    if (healPct > 0) heal(p, dmg * healPct);
                }
                if (++i >= steps) finishDash();
            }
            private void finishDash() {
                cancel();
                if (trailLife > 0) startTrail(path, particle, trailLife, k.color);
            }
        }.runTaskTimer(plugin, 0L, 1L);
        return true;
    }

    private void startTrail(final List<Location> path, final String particle, final int life, final String color) {
        new BukkitRunnable() {
            int t = 0;
            public void run() {
                for (Location l : path) Util.particle(l, particle, 2, 0.15, 0.15, 0.15, 0.01, color);
                t += 4;
                if (t >= life) cancel();
            }
        }.runTaskTimer(plugin, 4L, 4L);
    }

    // ===================================================================== WAVE

    private boolean wave(final Player p, final Katana k, final AbilityDef a, final int level) {
        final Location start = p.getEyeLocation().add(0, -0.4, 0);
        final Vector dir = start.getDirection().normalize();
        Vector s = new Vector(-dir.getZ(), 0, dir.getX());
        if (s.lengthSquared() < 0.001) s = new Vector(1, 0, 0); else s.normalize();
        final Vector side = s;
        final double range = a.d("range", 14);
        final double width = a.d("width", 1.6);
        final double kb = a.d("knockback", 0.8);
        final double dmg = a.d("damage", 5) * scale(level);
        final String particle = a.s("particle", k.auraParticle);
        final List<String> fx = a.list("effects");
        final Set<UUID> hit = new HashSet<UUID>();

        new BukkitRunnable() {
            double d = 1.0;
            public void run() {
                if (!p.isOnline()) { cancel(); return; }
                for (int step = 0; step < 2; step++) {
                    d += 1.0;
                    Location pt = start.clone().add(dir.clone().multiply(d));
                    if (!pt.getBlock().isPassable()) { cancel(); return; }
                    for (double w = -width; w <= width; w += 0.4) {
                        Location q = pt.clone().add(side.clone().multiply(w));
                        q.add(0, Math.abs(w) / width * 0.4, 0);
                        Util.particle(q, particle, 1, 0, 0, 0, 0, k.color);
                    }
                    for (LivingEntity t : nearby(pt, width, p)) {
                        if (!hit.add(t.getUniqueId())) continue;
                        hurt(p, t, dmg);
                        Vector v = dir.clone().multiply(kb);
                        v.setY(0.25);
                        t.setVelocity(v);
                        applyEffects(t, p, fx);
                    }
                    if (d >= range) { cancel(); return; }
                }
            }
        }.runTaskTimer(plugin, 0L, 1L);
        return true;
    }

    // ===================================================================== BOLT

    private boolean bolt(Player p, Katana k, AbilityDef a, int level) {
        double range = a.d("range", 24);
        double dmg = a.d("damage", 7) * scale(level);
        List<String> fx = a.list("effects");
        String particle = a.s("particle", k.auraParticle);
        LivingEntity t = lookTarget(p, range);
        if (t == null) {
            if (!a.b("allow-ground", true)) return false;
            Location at = rayEnd(p, range);
            strikeVisual(at, particle, k.color);
            for (LivingEntity e : nearby(at, 3.0, p)) { hurt(p, e, dmg); applyEffects(e, p, fx); }
            return true;
        }
        strikeVisual(t.getLocation(), particle, k.color);
        hurt(p, t, dmg);
        applyEffects(t, p, fx);
        int jumps = a.i("chain", 0);
        if (jumps > 0) chain(p, t, jumps, a.d("chain-radius", 6), dmg, fx, particle, k.color);
        return true;
    }

    private void strikeVisual(Location at, String particle, String color) {
        if (at.getWorld() == null) return;
        at.getWorld().strikeLightningEffect(at);
        Util.particle(at.clone().add(0, 1, 0), particle, 25, 0.4, 1.2, 0.4, 0.05, color);
    }

    private void chain(Player p, LivingEntity origin, int jumps, double radius, double dmg, List<String> fx, String particle, String color) {
        Set<UUID> visited = new HashSet<UUID>();
        visited.add(origin.getUniqueId());
        LivingEntity cur = origin;
        double d = dmg;
        for (int j = 0; j < jumps; j++) {
            LivingEntity next = null;
            double best = Double.MAX_VALUE;
            for (LivingEntity e : nearby(cur.getLocation(), radius, p)) {
                if (visited.contains(e.getUniqueId())) continue;
                double dd = e.getLocation().distanceSquared(cur.getLocation());
                if (dd < best) { best = dd; next = e; }
            }
            if (next == null) return;
            visited.add(next.getUniqueId());
            Util.line(cur.getEyeLocation(), next.getEyeLocation(), particle, color);
            strikeVisual(next.getLocation(), particle, color);
            d *= 0.75;
            hurt(p, next, d);
            applyEffects(next, p, fx);
            cur = next;
        }
    }

    // ==================================================================== BLINK

    private boolean blink(Player p, Katana k, AbilityDef a, int level) {
        LivingEntity t = lookTarget(p, a.d("range", 20));
        if (t == null) { plugin.bar(p, "&cNo target in sight."); return false; }
        teleportBehind(p, t);
        hurt(p, t, a.d("damage", 7) * scale(level) * 1.5);
        applyEffects(t, p, a.list("effects"));
        return true;
    }

    private void teleportBehind(Player p, LivingEntity t) {
        Location tl = t.getLocation();
        Vector back = tl.getDirection().setY(0);
        if (back.lengthSquared() < 0.01) back = p.getLocation().getDirection().setY(0).multiply(-1);
        if (back.lengthSquared() < 0.01) back = new Vector(1, 0, 0);
        back.normalize().multiply(-1.3);
        Location dest = tl.clone().add(back);
        if (!passable(dest)) dest = tl.clone();
        Vector look = tl.toVector().subtract(dest.toVector());
        if (look.lengthSquared() > 0.01) dest.setDirection(look);
        Util.particle(p.getLocation().add(0, 1, 0), "SQUID_INK", 20, 0.3, 0.6, 0.3, 0.05, "#4B0082");
        p.teleport(dest);
        Util.particle(dest.clone().add(0, 1, 0), "SQUID_INK", 20, 0.3, 0.6, 0.3, 0.05, "#4B0082");
    }

    // ==================================================================== PULSE

    private boolean pulse(Player p, Katana k, AbilityDef a, int level) {
        double sc = scale(level);
        double radius = a.d("radius", 8) * (0.8 + 0.2 * level / 12.0);
        double strength = a.d("strength", 1.2);
        double dmg = a.d("damage", 0) * sc;
        boolean cone = a.b("cone", false);
        String mode = a.s("mode", "PUSH").toUpperCase(Locale.ROOT);
        if (mode.equals("TOGGLE")) {
            if (pullMode.remove(p.getUniqueId())) mode = "PUSH";
            else { pullMode.add(p.getUniqueId()); mode = "PULL"; }
            plugin.bar(p, "&7Gravity: &f" + mode);
        }
        boolean pull = mode.equals("PULL");
        Location c = p.getLocation().clone();
        Vector look = p.getEyeLocation().getDirection().normalize();
        List<String> fx = a.list("effects");
        String particle = a.s("particle", k.auraParticle);

        for (LivingEntity t : nearby(c, radius, p)) {
            Vector to = t.getLocation().toVector().subtract(c.toVector());
            if (to.lengthSquared() < 0.01) continue;
            Vector n = to.clone().normalize();
            if (cone && n.dot(look) < 0.3) continue;
            Vector v = n.multiply(pull ? -strength : strength);
            v.setY(0.3);
            t.setVelocity(v);
            hurt(p, t, dmg);
            applyEffects(t, p, fx);
        }
        if (a.b("projectiles", true)) {
            for (Entity e : c.getWorld().getNearbyEntities(c, radius, radius, radius)) {
                if (!(e instanceof Projectile) || isOwn(e, p) || e.isOnGround()) continue;
                Vector to = e.getLocation().toVector().subtract(c.toVector());
                if (to.lengthSquared() < 0.01) continue;
                e.setVelocity(to.normalize().multiply(pull ? -strength : strength));
            }
        }
        for (int r = 1; r <= 3; r++) Util.ring(c.clone().add(0, 0.5 * r, 0), radius * r / 3.0, 28, particle, k.color, 0);
        return true;
    }

    // ================================================================== BARRIER

    private boolean barrier(final Player p, final Katana k, AbilityDef a, int level) {
        final double radius = a.d("radius", 4);
        final int ticks = (int) (a.d("duration", 4) * 20);
        final boolean reflect = a.b("reflect", false);
        final String particle = a.s("particle", k.auraParticle);
        final BarrierState st = new BarrierState();
        st.until = System.currentTimeMillis() + ticks * 50L;
        st.anchor = a.b("anchor", false);
        st.reduction = a.d("reduction", 0);
        st.recoil = a.list("recoil");
        barriers.put(p.getUniqueId(), st);
        for (String s : a.list("self-effects")) {
            PotionEffect pe = Util.effect(s, ticks, false, true);
            if (pe != null) p.addPotionEffect(pe, true);
        }
        new BukkitRunnable() {
            public void run() {
                if (!p.isOnline() || p.isDead() || System.currentTimeMillis() > st.until) {
                    if (barriers.get(p.getUniqueId()) == st) barriers.remove(p.getUniqueId());
                    cancel();
                    return;
                }
                Location c = p.getLocation().add(0, 1, 0);
                for (int i = 0; i < 10; i++) {
                    double u = rnd.nextDouble() * 2 - 1, th = rnd.nextDouble() * Math.PI * 2, r = Math.sqrt(1 - u * u);
                    Util.particle(c.clone().add(radius * 0.9 * r * Math.cos(th), radius * 0.9 * u, radius * 0.9 * r * Math.sin(th)),
                            particle, 1, 0, 0, 0, 0, k.color);
                }
                for (Entity e : c.getWorld().getNearbyEntities(c, radius, radius, radius)) {
                    if (!(e instanceof Projectile) || isOwn(e, p) || e.isOnGround()) continue;
                    Projectile pr = (Projectile) e;
                    if (reflect) {
                        pr.setVelocity(pr.getVelocity().multiply(-1));
                        try { pr.setShooter(p); } catch (Throwable ignored) { }
                    } else {
                        Util.particle(pr.getLocation(), particle, 6, 0.1, 0.1, 0.1, 0.02, k.color);
                        pr.remove();
                    }
                    plugin.progression().onBlocked(p, k, 1);
                }
            }
        }.runTaskTimer(plugin, 0L, 2L);
        return true;
    }

    /** Called from the damage listener when a barrier owner is hit. */
    public void onVictimHit(Player victim, EntityDamageByEntityEvent e) {
        BarrierState st = barriers.get(victim.getUniqueId());
        if (st == null || st.until < System.currentTimeMillis()) return;
        if (st.reduction > 0) e.setDamage(e.getDamage() * (1.0 - st.reduction));
        Entity d = e.getDamager();
        if (d instanceof LivingEntity && !st.recoil.isEmpty()) {
            LivingEntity att = (LivingEntity) d;
            applyEffects(att, victim, st.recoil);
            Vector away = att.getLocation().toVector().subtract(victim.getLocation().toVector());
            if (away.lengthSquared() > 0.01) {
                Vector v = away.normalize().multiply(0.6);
                v.setY(0.25);
                att.setVelocity(v);
            }
        }
    }

    public boolean isAnchored(Player p) {
        BarrierState st = barriers.get(p.getUniqueId());
        return st != null && st.anchor && st.until >= System.currentTimeMillis();
    }

    // ================================================================== DOMAIN

    private boolean domain(final Player p, final Katana k, final AbilityDef a, final int level) {
        UUID u = p.getUniqueId();
        if (activeDomains.contains(u)) { plugin.bar(p, "&cYour domain is already active."); return false; }
        final Domain dom = new Domain(p, k, a, level);
        activeDomains.add(u);
        int pre = a.b("circle", false) ? 30 : 0;
        if (pre <= 0) { dom.runTaskTimer(plugin, 0L, INTERVAL); return true; }

        final Location sky = dom.center().clone().add(0, a.d("circle-height", 8), 0);
        final double r = Math.min(8.0, dom.radius * 0.6);
        new BukkitRunnable() {
            int t = 0;
            public void run() {
                if (!p.isOnline() || p.isDead()) { activeDomains.remove(p.getUniqueId()); cancel(); return; }
                double rot = t * 0.12;
                Util.ring(sky, r, 36, k.auraParticle, k.color, rot);
                Util.ring(sky, r * 0.7, 28, a.s("particle2", k.auraParticle), k.color, -rot);
                for (int i = 0; i < 6; i++) { // hexagram
                    double a1 = rot + i * Math.PI / 3, a2 = rot + (i + 2) * Math.PI / 3;
                    Util.line(sky.clone().add(Math.cos(a1) * r * 0.7, 0, Math.sin(a1) * r * 0.7),
                            sky.clone().add(Math.cos(a2) * r * 0.7, 0, Math.sin(a2) * r * 0.7), k.auraParticle, k.color);
                }
                t += 2;
                if (t >= 30) { cancel(); dom.runTaskTimer(plugin, 0L, INTERVAL); }
            }
        }.runTaskTimer(plugin, 0L, 2L);
        return true;
    }

    private class Domain extends BukkitRunnable {
        final Player p;
        final Katana k;
        final int level;
        final double sc;
        final Location fixed;
        final boolean follow;
        final double radius, tickDmg, healPct, pull, lift, endBlast, strikeDmg, blinkDmg;
        final int duration, strikes, chainJumps, blinkInterval;
        final List<String> effects, selfEffects;
        final String particle, particle2, sky;
        final boolean blink, absorb;
        final List<ConfigurationSection> rains, spikes;
        final double[] rainAcc;
        int t = 0;

        Domain(Player p, Katana k, AbilityDef a, int level) {
            this.p = p;
            this.k = k;
            this.level = level;
            this.sc = scale(level);
            this.follow = a.b("follow", false);
            this.fixed = a.s("at", "SELF").equalsIgnoreCase("LOOK") ? rayEnd(p, 8) : p.getLocation().clone();
            this.radius = a.d("radius", 10);
            this.tickDmg = a.d("tick-damage", 0) * sc;
            this.healPct = a.d("heal-pct", 0);
            this.pull = a.d("pull", 0);
            this.lift = a.d("lift", 0);
            this.endBlast = a.d("end-blast", 0) * sc;
            this.strikes = a.i("strikes", 0);
            this.strikeDmg = a.d("strike-damage", 6) * sc;
            this.chainJumps = a.i("chain", 0);
            this.blink = a.b("blink", false);
            this.blinkInterval = Math.max(INTERVAL, a.i("blink-interval", 20));
            this.blinkDmg = a.d("blink-damage", 8) * sc;
            this.absorb = a.b("absorb-projectiles", false);
            this.duration = (int) Math.max(40, a.d("duration", 10) * 20 * (0.5 + 0.5 * Math.min(12, level) / 12.0));
            this.effects = a.list("effects");
            this.selfEffects = a.list("self-effects");
            this.particle = a.s("particle", k.auraParticle);
            this.particle2 = a.s("particle2", k.auraParticle);
            this.sky = a.s("sky", "").toUpperCase(Locale.ROOT);
            this.rains = a.sections("rain");
            this.spikes = a.sections("spikes");
            this.rainAcc = new double[rains.size()];
        }

        Location center() { return follow ? p.getLocation().clone() : fixed; }

        public void run() {
            if (!p.isOnline() || p.isDead()) { finish(false); return; }
            Location c = center();
            World w = c.getWorld();
            if (w == null) { finish(false); return; }
            double dt = INTERVAL / 20.0;
            double rot = t * 0.15;

            // visuals
            Util.ring(c.clone().add(0, 0.2, 0), radius, (int) Math.min(48, radius * 4), particle, k.color, rot);
            Util.ring(c.clone().add(0, 0.2, 0), radius * 0.55, 20, particle2, k.color, -rot);
            for (int i = 0; i < 6; i++) {
                double ang = rnd.nextDouble() * Math.PI * 2, rr = rnd.nextDouble() * radius;
                Util.particle(c.clone().add(Math.cos(ang) * rr, 0.3 + rnd.nextDouble() * 3, Math.sin(ang) * rr),
                        particle, 1, 0.1, 0.1, 0.1, 0.01, k.color);
            }
            if (!sky.isEmpty()) applySky(c);

            // damage / effects
            double healed = 0;
            for (LivingEntity e : nearby(c, radius, p)) {
                if (tickDmg > 0) { double d = tickDmg * dt; hurt(p, e, d); healed += d; }
                applyEffects(e, p, effects);
                Vector off = e.getLocation().toVector().subtract(c.toVector());
                if (pull > 0 && off.lengthSquared() > 0.5) {
                    Vector v = off.clone().normalize().multiply(-pull);
                    v.setY(0.1);
                    e.setVelocity(v);
                }
                if (lift > 0) {
                    Vector tan = new Vector(-off.getZ(), 0, off.getX());
                    if (tan.lengthSquared() > 0.01) tan.normalize().multiply(0.5);
                    tan.setY(lift);
                    e.setVelocity(tan);
                }
            }
            if (healPct > 0 && healed > 0) heal(p, healed * healPct);

            if (t % 20 == 0) {
                for (String s : selfEffects) {
                    PotionEffect pe = Util.effect(s, 60, false, true);
                    if (pe != null) p.addPotionEffect(pe, true);
                }
                for (int i = 0; i < strikes; i++) lightning(c);
            }

            // rains (snowballs / TNT / tridents)
            for (int ri = 0; ri < rains.size(); ri++) {
                ConfigurationSection r = rains.get(ri);
                if (level < r.getInt("min-level", 1)) continue;
                double spanTicks = r.getDouble("span-seconds", duration / 20.0) * 20.0;
                if (t >= spanTicks) continue;
                rainAcc[ri] += r.getDouble("count", 20) / Math.max(1.0, spanTicks / INTERVAL);
                while (rainAcc[ri] >= 1.0) { rainAcc[ri] -= 1.0; spawnRain(c, r); }
            }

            // ice spikes etc.
            if (t % 40 == 20) {
                for (ConfigurationSection s : spikes) if (level >= s.getInt("min-level", 1)) spawnSpikes(c, s);
            }

            // shadow blink strikes
            if (blink && t > 0 && t % blinkInterval == 0) {
                List<LivingEntity> list = nearby(c, radius, p);
                if (!list.isEmpty()) {
                    LivingEntity tg = list.get(rnd.nextInt(list.size()));
                    teleportBehind(p, tg);
                    hurt(p, tg, blinkDmg);
                }
            }

            if (absorb) {
                for (Entity e : w.getNearbyEntities(c, radius, radius, radius)) {
                    if (e instanceof Projectile && !isOwn(e, p)) {
                        e.remove();
                        plugin.progression().onBlocked(p, k, 1);
                    }
                }
            }

            t += INTERVAL;
            if (t >= duration) {
                if (endBlast > 0) {
                    for (LivingEntity e : nearby(c, radius, p)) {
                        hurt(p, e, endBlast);
                        Vector v = e.getLocation().toVector().subtract(c.toVector());
                        if (v.lengthSquared() > 0.01) { v.normalize().multiply(1.1); v.setY(0.5); e.setVelocity(v); }
                    }
                    Util.particle(c.clone().add(0, 1, 0), "EXPLOSION_LARGE", 6, radius / 3, 1, radius / 3, 0, k.color);
                    Util.sound(c, "ENTITY_GENERIC_EXPLODE", 1f, 0.8f);
                }
                finish(true);
            }
        }

        void lightning(Location c) {
            double ang = rnd.nextDouble() * Math.PI * 2, rr = Math.sqrt(rnd.nextDouble()) * radius;
            Location at = c.clone().add(Math.cos(ang) * rr, 0, Math.sin(ang) * rr);
            strikeVisual(at, particle, k.color);
            Util.sound(at, "ENTITY_LIGHTNING_BOLT_THUNDER|ENTITY_LIGHTNING_THUNDER", 0.6f, 1f);
            List<LivingEntity> hits = nearby(at, 3.0, p);
            for (LivingEntity e : hits) {
                hurt(p, e, strikeDmg);
                applyEffects(e, p, effects);
            }
            if (chainJumps > 0 && !hits.isEmpty()) chain(p, hits.get(0), chainJumps, 6, strikeDmg, effects, particle, k.color);
        }

        void applySky(Location c) {
            double r = radius + 25;
            for (Player pl : c.getWorld().getPlayers()) {
                if (pl.getLocation().distanceSquared(c) > r * r) continue;
                if (sky.contains("NIGHT")) pl.setPlayerTime(18000L, false);
                if (sky.contains("STORM")) pl.setPlayerWeather(WeatherType.DOWNFALL);
                skyPlayers.add(pl.getUniqueId());
            }
        }

        void finish(boolean natural) {
            try { cancel(); } catch (IllegalStateException ignored) { }
            activeDomains.remove(p.getUniqueId());
            if (!sky.isEmpty()) resetSky();
        }
    }

    private void resetSky() {
        if (!activeDomains.isEmpty()) return; // another domain still running
        for (UUID id : skyPlayers) {
            Player pl = Bukkit.getPlayer(id);
            if (pl != null) { pl.resetPlayerTime(); pl.resetPlayerWeather(); }
        }
        skyPlayers.clear();
    }

    // ------------------------------------------------------------ rain entities

    private void spawnRain(Location c, ConfigurationSection r) {
        Player owner = null;
        // owner is resolved by the caller through metadata below; find the caster from the domain via nearest holder
        String en = r.getString("entity", "SNOWBALL").toUpperCase(Locale.ROOT);
        EntityType et = en.equals("TNT") ? Util.entityType("PRIMED_TNT", "TNT") : Util.entityType(en);
        if (et == null || c.getWorld() == null) return;
        if (rainAlive >= plugin.getConfig().getInt("abilities.max-rain-entities", 40)) return;
        for (Player pl : c.getWorld().getPlayers()) {
            if (activeDomains.contains(pl.getUniqueId()) && pl.getLocation().distanceSquared(c) < 900) { owner = pl; break; }
        }
        if (owner == null) return;
        double ang = rnd.nextDouble() * Math.PI * 2, rr = Math.sqrt(rnd.nextDouble()) * 12.0;
        Location loc = c.clone().add(Math.cos(ang) * rr, r.getDouble("height", 14), Math.sin(ang) * rr);
        final Entity ent;
        try { ent = c.getWorld().spawnEntity(loc, et); } catch (Throwable t) { return; }
        ent.setMetadata("katana_owner", new FixedMetadataValue(plugin, owner.getUniqueId().toString()));
        ent.setMetadata("katana_dmg", new FixedMetadataValue(plugin, r.getDouble("damage", 5)));
        ent.setMetadata("katana_fx", new FixedMetadataValue(plugin, String.join(";", r.getStringList("effects"))));
        if (ent instanceof TNTPrimed) {
            TNTPrimed tnt = (TNTPrimed) ent;
            tnt.setFuseTicks(r.getInt("fuse", 30));
            tnt.setYield((float) r.getDouble("yield", 1.5));
            tnt.setIsIncendiary(false);
            try { tnt.setSource(owner); } catch (Throwable ignored) { }
        } else {
            ent.setVelocity(new Vector((rnd.nextDouble() - 0.5) * 0.2, -r.getDouble("speed", 1.5), (rnd.nextDouble() - 0.5) * 0.2));
        }
        rainAlive++;
        Bukkit.getScheduler().runTaskLater(plugin, new Runnable() {
            public void run() {
                if (!ent.isDead()) ent.remove();
                rainAlive = Math.max(0, rainAlive - 1);
            }
        }, r.getInt("life-ticks", 80));
    }

    /** Falling snowball/trident hit something. Vanilla damage is cancelled in the listener; ours is applied here. */
    public void onRainHit(Projectile pr, Entity hit) {
        Player owner = ownerOf(pr);
        if (owner != null && hit instanceof LivingEntity && valid(owner, hit)) {
            LivingEntity le = (LivingEntity) hit;
            hurt(owner, le, metaDouble(pr, "katana_dmg", 4));
            String fx = metaString(pr, "katana_fx");
            if (fx != null && !fx.isEmpty()) applyEffects(le, owner, Arrays.asList(fx.split(";")));
        }
        pr.remove();
    }

    private void spawnSpikes(Location c, ConfigurationSection s) {
        final Player p = nearestCaster(c);
        if (p == null) return;
        final int count = s.getInt("count", 4);
        final double dmg = s.getDouble("damage", 8);
        final String pt = s.getString("particle", "CLOUD");
        final List<String> fx = s.getStringList("effects");
        for (int i = 0; i < count; i++) {
            double ang = rnd.nextDouble() * Math.PI * 2, rr = Math.sqrt(rnd.nextDouble()) * 10.0;
            final Location loc = c.clone().add(Math.cos(ang) * rr, 0, Math.sin(ang) * rr);
            Util.ring(loc.clone().add(0, 0.1, 0), 1.6, 12, pt, "#FFFFFF", 0);
            Bukkit.getScheduler().runTaskLater(plugin, new Runnable() {
                public void run() {
                    for (double y = 0; y < 4; y += 0.4) Util.particle(loc.clone().add(0, y, 0), pt, 6, 0.25, 0.1, 0.25, 0.01, "#FFFFFF");
                    Util.particle(loc.clone().add(0, 2, 0), "CLOUD", 10, 0.4, 1, 0.4, 0.02, "#FFFFFF");
                    for (LivingEntity e : nearby(loc.clone().add(0, 1, 0), 2.2, p)) {
                        hurt(p, e, dmg);
                        Vector v = e.getVelocity();
                        v.setY(0.9);
                        e.setVelocity(v);
                        applyEffects(e, p, fx);
                    }
                }
            }, 12L);
        }
    }

    private Player nearestCaster(Location c) {
        for (Player pl : c.getWorld().getPlayers()) {
            if (activeDomains.contains(pl.getUniqueId()) && pl.getLocation().distanceSquared(c) < 900) return pl;
        }
        return null;
    }

    // ================================================================= cleanup

    public void clearPlayer(Player p) {
        barriers.remove(p.getUniqueId());
        pullMode.remove(p.getUniqueId());
    }

    public void shutdown() {
        for (LivingEntity e : bound.values()) { if (!e.isDead()) e.setAI(true); }
        bound.clear();
        activeDomains.clear();
        for (UUID id : skyPlayers) {
            Player pl = Bukkit.getPlayer(id);
            if (pl != null) { pl.resetPlayerTime(); pl.resetPlayerWeather(); }
        }
        skyPlayers.clear();
        barriers.clear();
    }
}
