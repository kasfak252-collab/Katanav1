#!/usr/bin/env python3
"""
Builds the katana resource packs.

    python3 make_pack.py          (needs Pillow + numpy:  pip install pillow numpy)

Outputs (next to the plugin folder):
    KatanasPack.zip            64x64 HD, ANIMATED (16 frames, shine sweep + glow pulse + per-katana effect)
    KatanasPack-Classic16.zip  16x16 pixel-art, static

Models are attached to netherite_sword (and diamond_sword for pre-1.16 servers) through CustomModelData,
using the same numbers as `cmd:` in katanas.yml.  Works on 1.14 - 1.21.3 (model overrides) and 1.21.4+ (items/*.json).

Use your own art: replace the PNGs in assets/katanas/textures/item/ (file name = katana id).
For an animated texture keep the frames stacked vertically (square frames) and keep the .png.mcmeta next to it.
"""
import hashlib, json, math, os, random, shutil, sys, zipfile
import numpy as np
from PIL import Image, ImageDraw, ImageFilter

# id, custom_model_data, main colour, accent colour, effect style
KATANAS = [
    ("blaze_edge",      1001, "#FF5A1F", "#FFD23F", "ember"),
    ("red_destroyer",   1002, "#B3121A", "#FF7A59", "ember"),
    ("blue_tempest",    1003, "#1E90FF", "#9EE7FF", "bubble"),
    ("emerald_serpent", 1004, "#2ECC71", "#B8FF9E", "leaf"),
    ("golden_dawn",     1005, "#FFD700", "#FFF6B0", "star"),
    ("shadow_realm",    1006, "#4B0082", "#B388FF", "wisp"),
    ("frost_fang",      1007, "#7FDBFF", "#FFFFFF", "snow"),
    ("crimson_moon",    1008, "#B0001E", "#FF4D6D", "drip"),
    ("thunder_emperor", 1009, "#F1C40F", "#FFFFFF", "bolt"),
    ("void_reaper",     1010, "#6A0DAD", "#FF4DFF", "orbit"),
    ("inferno_wrath",   1011, "#FF6A00", "#FFE066", "ember"),
    ("jade_dragon",     1012, "#00A86B", "#C8FFE4", "leaf"),
    ("celestial_blade", 1013, "#00E5FF", "#FFFFFF", "star"),
    ("echo_pulse",      1014, "#3FA7D6", "#D6F3FF", "ring"),
    ("gravity_edge",    1015, "#A29BFE", "#FFFFFF", "orbit"),
]
BASES = ["netherite_sword", "diamond_sword"]

OUT = 64          # final texture size
SS = 4            # supersampling factor
S = OUT * SS
FRAMES = 16
FRAMETIME = 2     # ticks per frame (interpolated)

GOLD = (214, 178, 70)
LEATHER = (46, 36, 40)

# ----------------------------------------------------------------- small helpers

def rgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))

def mix(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))

def over(im, fn):
    """Draw with fn(draw) on a fresh transparent layer and alpha-composite it on im."""
    layer = Image.new("RGBA", im.size, (0, 0, 0, 0))
    fn(ImageDraw.Draw(layer))
    return Image.alpha_composite(im, layer)

def downsample(im, size):
    """Premultiplied-alpha LANCZOS resize (no dark fringes on transparent edges)."""
    a = np.asarray(im).astype(np.float32) / 255.0
    pm = a.copy()
    pm[..., :3] *= a[..., 3:4]
    chans = []
    for c in range(4):
        ch = Image.fromarray((pm[..., c] * 255).astype(np.uint8), "L").resize((size, size), Image.LANCZOS)
        chans.append(np.asarray(ch).astype(np.float32) / 255.0)
    out = np.stack(chans, axis=-1)
    alpha = out[..., 3:4]
    out[..., :3] = np.where(alpha > 1e-4, out[..., :3] / np.maximum(alpha, 1e-4), 0)
    return Image.fromarray((np.clip(out, 0, 1) * 255).astype(np.uint8), "RGBA")

# ------------------------------------------------------------------ katana geometry
# blade centre line = quadratic bezier, slightly curved (sori); edge on the +normal side.
P0, P1, P2 = (0.30, 0.70), (0.66, 0.47), (0.92, 0.08)

def bez(t):
    return ((1 - t) ** 2 * P0[0] + 2 * (1 - t) * t * P1[0] + t * t * P2[0],
            (1 - t) ** 2 * P0[1] + 2 * (1 - t) * t * P1[1] + t * t * P2[1])

def tan(t):
    dx = 2 * (1 - t) * (P1[0] - P0[0]) + 2 * t * (P2[0] - P1[0])
    dy = 2 * (1 - t) * (P1[1] - P0[1]) + 2 * t * (P2[1] - P1[1])
    l = math.hypot(dx, dy)
    return (dx / l, dy / l)

def norm(t):
    tx, ty = tan(t)
    return (-ty, tx)

def width(t):
    base = 0.066 * (1 - 0.22 * t)
    if t > 0.88:
        base = 0.066 * (1 - 0.22 * 0.88) * (1 - (t - 0.88) / 0.12) ** 0.8 + 0.004
    return base

def px(p):
    return (p[0] * S, p[1] * S)

def side(k, t0=0.0, t1=1.0, n=48):
    pts = []
    for i in range(n + 1):
        t = t0 + (t1 - t0) * i / n
        c, nn, w = bez(t), norm(t), width(t)
        pts.append(px((c[0] + nn[0] * w * k, c[1] + nn[1] * w * k)))
    return pts

def strip(d, k1, k2, col, t0=0.0, t1=1.0):
    d.polygon(side(k1, t0, t1) + list(reversed(side(k2, t0, t1))), fill=col)

def line_k(k, wob=0.0, freq=30, t0=0.05, t1=0.97, n=80):
    pts = []
    for i in range(n + 1):
        t = t0 + (t1 - t0) * i / n
        c, nn, w = bez(t), norm(t), width(t)
        kk = k + wob * math.sin(t * freq)
        pts.append(px((c[0] + nn[0] * w * kk, c[1] + nn[1] * w * kk)))
    return pts

def ellipse_poly(center, ax, ay, rx, ry, n=28):
    pts = []
    for i in range(n):
        a = 2 * math.pi * i / n
        pts.append(px((center[0] + ax[0] * rx * math.cos(a) + ay[0] * ry * math.sin(a),
                       center[1] + ax[1] * rx * math.cos(a) + ay[1] * ry * math.sin(a))))
    return pts

# --------------------------------------------------------------------- effects

def make_specs(style, seed):
    rnd = random.Random(seed)
    n = {"ember": 16, "snow": 14, "bubble": 10, "leaf": 9, "star": 9, "drip": 5, "wisp": 7, "bolt": 0, "orbit": 3, "ring": 2}[style]
    return [dict(t=rnd.uniform(0.18, 1.0), off=rnd.uniform(-1.2, 1.6), p=rnd.random(),
                 sz=rnd.uniform(0.7, 1.3), dx=rnd.uniform(-0.06, 0.06)) for _ in range(n)]

def star_poly(cx, cy, r):
    pts = []
    for i in range(8):
        a = i * math.pi / 4
        rr = r if i % 2 == 0 else r * 0.28
        pts.append((cx + rr * math.cos(a), cy + rr * math.sin(a)))
    return pts

def effects(im, style, f, main, acc, seed):
    specs = make_specs(style, seed)
    ph = f / FRAMES
    if style == "bolt":
        rnd = random.Random(seed * 1000 + f // 4)
        if f % 4 in (0, 1):
            def draw(d):
                for _ in range(2):
                    ta, tb = sorted((rnd.uniform(0.2, 0.9), rnd.uniform(0.2, 0.95)))
                    tb = max(tb, ta + 0.2)
                    pts = []
                    for i in range(6):
                        t = min(1.0, ta + (tb - ta) * i / 5)
                        c, nn = bez(t), norm(t)
                        off = rnd.uniform(0.04, 0.12) * (1 if i in (0, 5) else rnd.choice((-1.6, 1.6)))
                        pts.append(px((c[0] + nn[0] * off, c[1] + nn[1] * off)))
                    d.line(pts, fill=(255, 255, 200, 90), width=int(0.03 * S), joint="curve")
                    d.line(pts, fill=(255, 255, 255, 255), width=int(0.011 * S), joint="curve")
            im = over(im, draw)
        return im

    if style == "wisp":
        layer = Image.new("RGBA", im.size, mix(main, (0, 0, 0), 0.2) + (0,))
        d = ImageDraw.Draw(layer)
        for s in specs:
            u = (ph + s["p"]) % 1
            c, nn = bez(s["t"]), norm(s["t"])
            x = (c[0] + nn[0] * 0.04 * s["off"] + 0.05 * math.sin(u * 6.28 + s["p"] * 6)) * S
            y = (c[1] - 0.20 * u) * S
            r = (0.03 + 0.03 * u) * S * s["sz"]
            col = mix(main, acc, 0.35 + 0.3 * u) + (int(170 * math.sin(math.pi * u)),)
            d.ellipse((x - r, y - r, x + r, y + r), fill=col)
        layer = layer.filter(ImageFilter.GaussianBlur(0.012 * S))
        return Image.alpha_composite(im, layer)

    if style in ("orbit", "ring"):
        cen = bez(0.58)
        tx, ty = tan(0.58)
        nx, ny = norm(0.58)
        def draw(d):
            if style == "orbit":
                for i, s in enumerate(specs):
                    a = 2 * math.pi * (ph + i / 3.0)
                    x = cen[0] + nx * math.cos(a) * 0.13 + tx * math.sin(a) * 0.07
                    y = cen[1] + ny * math.cos(a) * 0.13 + ty * math.sin(a) * 0.07
                    r = 0.022 * S
                    X, Y = x * S, y * S
                    d.ellipse((X - r * 2, Y - r * 2, X + r * 2, Y + r * 2), fill=main + (70,))
                    d.ellipse((X - r, Y - r, X + r, Y + r), fill=acc + (255,))
            else:
                for j in range(2):
                    u = (ph + j * 0.5) % 1
                    rx, ry = 0.04 + 0.17 * u, 0.012 + 0.055 * u
                    pts = ellipse_poly(cen, (nx, ny), (tx, ty), rx, ry)
                    d.line(pts + [pts[0]], fill=acc + (int(210 * (1 - u)),), width=int(0.011 * S))
        return over(im, draw)

    def draw(d):
        for s in specs:
            u = (ph + s["p"]) % 1
            fade = math.sin(math.pi * u)
            t = s["t"]
            c, nn = bez(t), norm(t)
            bx, by = c[0] + nn[0] * (0.03 + s["off"] * 0.035), c[1] + nn[1] * (0.03 + s["off"] * 0.035)
            sz = s["sz"]
            if style == "ember":
                x, y = (bx + s["dx"] * u + 0.01 * math.sin(u * 6 + s["p"] * 6)) * S, (by - 0.17 * u) * S
                r = 0.014 * sz * S * (1 - 0.5 * u)
                col = mix(acc, main, u)
                d.ellipse((x - r * 2, y - r * 2, x + r * 2, y + r * 2), fill=col + (int(60 * fade),))
                d.ellipse((x - r, y - r, x + r, y + r), fill=col + (int(240 * fade),))
            elif style == "snow":
                x, y = (bx - 0.02 + 0.02 * math.sin(u * 6.28 + s["p"] * 6)) * S, (by - 0.06 + 0.15 * u) * S
                r = 0.011 * sz * S
                d.ellipse((x - r, y - r, x + r, y + r), fill=(255, 255, 255, int(235 * fade)))
                d.line((x - r * 2, y, x + r * 2, y), fill=acc + (int(120 * fade),), width=max(1, int(0.004 * S)))
                d.line((x, y - r * 2, x, y + r * 2), fill=acc + (int(120 * fade),), width=max(1, int(0.004 * S)))
            elif style == "bubble":
                x, y = (bx + 0.015 * math.sin(u * 8 + s["p"] * 6)) * S, (by - 0.16 * u) * S
                r = 0.02 * sz * S * (0.7 + 0.5 * u)
                d.ellipse((x - r, y - r, x + r, y + r), outline=acc + (int(220 * fade),), width=max(1, int(0.005 * S)))
                d.ellipse((x - r * 0.45, y - r * 0.5, x - r * 0.1, y - r * 0.15), fill=(255, 255, 255, int(220 * fade)))
            elif style == "leaf":
                x, y = (bx + 0.13 * u + 0.02 * math.sin(u * 12.5 + s["p"] * 6)) * S, (by - 0.05 * u + 0.02 * math.sin(u * 9)) * S
                ang = u * math.pi * 2 + s["p"] * 6
                a1, a2 = (math.cos(ang), math.sin(ang)), (-math.sin(ang), math.cos(ang))
                rx, ry = 0.026 * sz * S, 0.011 * sz * S
                pts = [(x + a1[0] * rx * math.cos(a) + a2[0] * ry * math.sin(a),
                        y + a1[1] * rx * math.cos(a) + a2[1] * ry * math.sin(a))
                       for a in [i * math.pi / 6 for i in range(12)]]
                d.polygon(pts, fill=mix(main, acc, 0.4 * u) + (int(235 * fade),))
            elif style == "star":
                x, y = bx * S, by * S
                r = 0.05 * sz * S * fade
                if r > 1:
                    d.polygon(star_poly(x, y, r), fill=acc + (230,))
                    d.ellipse((x - r * 0.18, y - r * 0.18, x + r * 0.18, y + r * 0.18), fill=(255, 255, 255, 255))
            elif style == "drip":
                t2 = 0.25 + 0.5 * s["t"]
                c2, n2 = bez(t2), norm(t2)
                w2 = width(t2)
                x0, y0 = c2[0] + n2[0] * w2 * 0.62, c2[1] + n2[1] * w2 * 0.62
                x, y = x0 * S, (y0 + 0.26 * u * u) * S
                r = 0.017 * sz * S
                a = 255 if u < 0.85 else int(255 * (1 - u) / 0.15)
                col = mix(main, (0, 0, 0), 0.15) + (a,)
                d.polygon([(x, y - r * 2.2), (x - r, y), (x, y + r), (x + r, y)], fill=col)
                d.ellipse((x - r, y - r * 0.6, x + r, y + r * 1.2), fill=col)
    return over(im, draw)

# --------------------------------------------------------------------- one frame

def render_frame(main_hex, accent_hex, style, f, seed):
    main, acc = rgb(main_hex), rgb(accent_hex)
    dark = mix(main, (0, 0, 0), 0.45)
    mid = mix(main, (255, 255, 255), 0.30)
    light = mix(main, (255, 255, 255), 0.78)
    im = Image.new("RGBA", (S, S), (0, 0, 0, 0))

    # glow around the blade (pulsing)
    pulse = 0.55 + 0.45 * math.sin(2 * math.pi * f / FRAMES)
    glow = Image.new("RGBA", (S, S), acc + (0,))
    ImageDraw.Draw(glow).line([px(bez(i / 40)) for i in range(41)], fill=acc + (int(150 * pulse),),
                              width=int(0.085 * S), joint="curve")
    im = Image.alpha_composite(im, glow.filter(ImageFilter.GaussianBlur(0.035 * S)))

    t0, n0 = tan(0), norm(0)
    # handle (tsuka) + diamond wrap + pommel
    L, hw = 0.23, 0.034
    A = (P0[0] + n0[0] * hw, P0[1] + n0[1] * hw)
    B = (P0[0] - n0[0] * hw, P0[1] - n0[1] * hw)
    C = (B[0] - t0[0] * L, B[1] - t0[1] * L)
    D = (A[0] - t0[0] * L, A[1] - t0[1] * L)

    def handle(d):
        d.polygon([px(A), px(B), px(C), px(D)], fill=LEATHER + (255,))
        for k in range(6):
            cx, cy = P0[0] - t0[0] * (0.035 + 0.033 * k), P0[1] - t0[1] * (0.035 + 0.033 * k)
            h = 0.02
            pts = [px((cx + t0[0] * h, cy + t0[1] * h)), px((cx + n0[0] * h, cy + n0[1] * h)),
                   px((cx - t0[0] * h, cy - t0[1] * h)), px((cx - n0[0] * h, cy - n0[1] * h))]
            d.polygon(pts, fill=mix(acc, main, 0.35) + (255,), outline=dark + (255,))
        ce = (P0[0] - t0[0] * (L + 0.012), P0[1] - t0[1] * (L + 0.012))
        d.polygon(ellipse_poly(ce, n0, t0, 0.038, 0.03), fill=GOLD + (255,))
    im = over(im, handle)

    # blade body
    def blade(d):
        strip(d, -0.38, 0.62, mid + (255,))
        strip(d, -0.38, -0.10, dark + (255,))      # ridge (shinogi)
        strip(d, 0.38, 0.62, light + (255,))       # edge bevel
    im = over(im, blade)

    # hamon + specular line (translucent)
    def hamon(d):
        d.line(line_k(0.28, 0.07), fill=(255, 255, 255, 150), width=max(2, int(0.008 * S)), joint="curve")
        d.line(line_k(-0.12), fill=(255, 255, 255, 80), width=max(1, int(0.005 * S)), joint="curve")
    im = over(im, hamon)

    # travelling shine
    tc = f / FRAMES * 1.5 - 0.25
    ta, tb = max(0.0, tc - 0.07), min(1.0, tc + 0.07)
    if tb - ta > 0.01:
        im = over(im, lambda d: strip(d, -0.38, 0.62, (255, 255, 255, 185), ta, tb))

    # guard (tsuba)
    def tsuba(d):
        d.polygon(ellipse_poly(P0, n0, t0, 0.082, 0.024), fill=GOLD + (255,), outline=mix(GOLD, (0, 0, 0), 0.45) + (255,))
        d.polygon(ellipse_poly(P0, n0, t0, 0.05, 0.012), fill=mix(GOLD, (255, 255, 255), 0.35) + (255,))
    im = over(im, tsuba)

    im = effects(im, style, f, main, acc, seed)
    return downsample(im, OUT)

# ------------------------------------------------------------------ pack writing

def classic16(main_hex, accent_hex):
    main, accent = rgb(main_hex), rgb(accent_hex)
    blade = mix(main, (255, 255, 255), 0.55)
    edge = mix(main, (0, 0, 0), 0.35)
    glow = mix(accent, main, 0.2)
    im = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    p = im.load()

    def put(x, y, c, a=255):
        if 0 <= x < 16 and 0 <= y < 16:
            p[x, y] = (c[0], c[1], c[2], a)
    for i, x in enumerate((1, 2, 3)):
        put(x, 15 - x, LEATHER)
        put(x, 16 - x, accent if i % 2 == 0 else LEATHER)
    put(0, 15, LEATHER)
    for dx, dy in ((-1, -1), (0, 0), (1, 1)):
        put(4 + dx, 11 + dy, GOLD)
    put(4, 12, mix(GOLD, (0, 0, 0), 0.3))
    for x in range(5, 14):
        y = 15 - x
        put(x, y, blade)
        put(x, y + 1, edge)
        if x % 2 == 1:
            put(x, y - 1, glow, 150)
    put(14, 1, (255, 255, 255))
    put(13, 2, mix(blade, (255, 255, 255), 0.6))
    return im

def write_models(root):
    mod = os.path.join(root, "assets", "katanas", "models", "item")
    vm = os.path.join(root, "assets", "minecraft", "models", "item")
    vi = os.path.join(root, "assets", "minecraft", "items")
    for d in (mod, vm, vi):
        os.makedirs(d, exist_ok=True)
    for kid, cmd, _, _, _ in KATANAS:
        with open(os.path.join(mod, kid + ".json"), "w") as f:
            json.dump({"parent": "minecraft:item/handheld", "textures": {"layer0": "katanas:item/" + kid}}, f, indent=2)
    for base in BASES:
        with open(os.path.join(vm, base + ".json"), "w") as f:      # 1.14 - 1.21.3
            json.dump({"parent": "minecraft:item/handheld", "textures": {"layer0": "minecraft:item/" + base},
                       "overrides": [{"predicate": {"custom_model_data": c}, "model": "katanas:item/" + k}
                                     for k, c, _, _, _ in KATANAS]}, f, indent=2)
        with open(os.path.join(vi, base + ".json"), "w") as f:      # 1.21.4+
            json.dump({"model": {"type": "minecraft:range_dispatch", "property": "minecraft:custom_model_data",
                                 "fallback": {"type": "minecraft:model", "model": "minecraft:item/" + base},
                                 "entries": [{"threshold": c, "model": {"type": "minecraft:model", "model": "katanas:item/" + k}}
                                             for k, c, _, _, _ in KATANAS]}}, f, indent=2)
    with open(os.path.join(root, "pack.mcmeta"), "w") as f:
        json.dump({"pack": {"pack_format": 34, "supported_formats": {"min_inclusive": 4, "max_inclusive": 999},
                            "description": "Katanas - 15 custom katana models"}}, f, indent=2)

def zip_dir(root, out):
    if os.path.exists(out):
        os.remove(out)
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for folder, _, files in os.walk(root):
            for fn in sorted(files):
                full = os.path.join(folder, fn)
                z.write(full, os.path.relpath(full, root).replace(os.sep, "/"))
    return hashlib.sha1(open(out, "rb").read()).hexdigest()

def build(kind, base_dir):
    root = os.path.join(base_dir, "resourcepack" if kind == "hd" else "resourcepack_classic16")
    if os.path.isdir(root):
        shutil.rmtree(root)
    tex = os.path.join(root, "assets", "katanas", "textures", "item")
    os.makedirs(tex)
    for i, (kid, cmd, main, acc, style) in enumerate(KATANAS):
        if kind == "hd":
            sheet = Image.new("RGBA", (OUT, OUT * FRAMES), (0, 0, 0, 0))
            for f in range(FRAMES):
                sheet.paste(render_frame(main, acc, style, f, 100 + i), (0, f * OUT))
            sheet.save(os.path.join(tex, kid + ".png"), optimize=True)
            with open(os.path.join(tex, kid + ".png.mcmeta"), "w") as fh:
                json.dump({"animation": {"frametime": FRAMETIME, "interpolate": True}}, fh, indent=2)
        else:
            classic16(main, acc).save(os.path.join(tex, kid + ".png"))
    write_models(root)
    name = "KatanasPack.zip" if kind == "hd" else "KatanasPack-Classic16.zip"
    out = os.path.join(base_dir, name)
    sha = zip_dir(root, out)
    print("wrote", out, os.path.getsize(out) // 1024, "KB  sha1", sha)
    return sha, root

def preview(base_dir):
    """Contact sheet: frame 0 of every katana + 6 frames of two animated ones."""
    cell = 128
    sheet = Image.new("RGBA", (5 * cell, 3 * cell + 2 * cell), (36, 36, 46, 255))
    for i, (kid, cmd, main, acc, style) in enumerate(KATANAS):
        fr = render_frame(main, acc, style, 4, 100 + i).resize((cell, cell), Image.NEAREST)
        sheet.alpha_composite(fr, ((i % 5) * cell, (i // 5) * cell))
    for row, idx in enumerate((0, 8)):                    # blaze_edge, thunder_emperor
        kid, cmd, main, acc, style = KATANAS[idx]
        for j in range(5):
            fr = render_frame(main, acc, style, j * 3, 100 + idx).resize((cell, cell), Image.NEAREST)
            sheet.alpha_composite(fr, (j * cell, (3 + row) * cell))
    sheet.save(os.path.join(base_dir, "preview.png"))

def main():
    base = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
    sha_hd, _ = build("hd", base)
    sha_cl, _ = build("classic", base)
    with open(os.path.join(base, "pack-sha1.txt"), "w") as f:
        f.write(sha_hd + "\n")
    with open(os.path.join(base, "pack-classic-sha1.txt"), "w") as f:
        f.write(sha_cl + "\n")
    if "--no-preview" not in sys.argv:
        preview(base)

if __name__ == "__main__":
    main()
